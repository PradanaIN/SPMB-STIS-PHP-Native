<?php
/* ========== KONEKSI KE DATABASE ========== */
$conn = mysqli_connect("localhost", "root", "", "spmb_stis");

/* ========== MENGAMBIL DATA DARI DATABASE ========== */
function query($query)
{
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

/* ========== TAMBAH PESERTA BARU ========== */
function tambah_peserta($data)
{
    global $conn;
    // data diri peserta
    $nik = htmlspecialchars($data["nik"]);
    $nama = htmlspecialchars($data["nama"]);
    $jenis_kelamin = htmlspecialchars($data["jenis_kelamin"]);
    $tanggal_lahir = htmlspecialchars($data["tanggal_lahir"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $gambar = htmlspecialchars($data["gambar"]);
    // detail pelaksanaan tes
    // $nomor_tes = htmlspecialchars($data["nomor_tes"]);
    $prodi = htmlspecialchars($data["prodi"]);
    $formasi = htmlspecialchars($data["formasi"]);
    $tahap_1 = htmlspecialchars($data["tahap_1"]);
    // $tahap_2 = htmlspecialchars($data["tahap_2"]);
    // $tahap_3 = htmlspecialchars($data["tahap_3"]);

    // cek nik sudah ada atau belum
    $result = mysqli_query($conn, "SELECT * FROM peserta WHERE nik = '$nik'");
    if (mysqli_fetch_assoc($result)) {
        echo "<script>
                alert('NIK sudah terdaftar!');
            </script>";
        return false;
    }

    // upload gambar
    $gambar = upload_gambar();
    if (!$gambar) {
        return false;
    }

    // query insert data
    $query = "INSERT INTO peserta
                VALUES
                ('', '$nama', '$jenis_kelamin', '$tanggal_lahir', '$nik', '$alamat', '$prodi', '$formasi', '$tahap_1', ' ', ' ', '$gambar')
            ";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

/* ========== TAMBAH PENGAWAS BARU ========== */
function tambah_pengawas($data)
{
    global $conn;
    // data diri pengawas
    $nama = htmlspecialchars($data["nama"]);
    $status = htmlspecialchars($data["status"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $nip = htmlspecialchars($data["nip"]);
    $password = htmlspecialchars($data["password"]);
    $gambar = htmlspecialchars($data["gambar"]);
    // detail pelaksanaan tes
    $tahap_1 = htmlspecialchars($data["tahap_1"]);
    $lokasi_1 = htmlspecialchars($data["lokasi_1"]);
    // $tahap_2 = htmlspecialchars($data["tahap_2"]);
    // $lokasi_2 = htmlspecialchars($data["lokasi_2"]);
    // $tahap_3 = htmlspecialchars($data["tahap_3"]);
    // $lokasi_3 = htmlspecialchars($data["lokasi_3"]);

    // cek nip sudah ada atau belum
    $result = mysqli_query($conn, "SELECT * FROM pengawas WHERE nip = '$nip'");
    
    if (mysqli_fetch_assoc($result)) {
        echo "<script>
                alert('NIP sudah terdaftar!');
            </script>";
        return false;
    }

    // upload gambar
    $gambar = upload_gambar();
    if (!$gambar) {
        return false;
    }

    //enkripsi password
    $password = password_hash($password, PASSWORD_DEFAULT);

    // query insert data
    $query = "INSERT INTO pengawas
                VALUES
                ('', '$nama', '$status', '$alamat', '$nip', '$password', '$gambar', '$tahap_1', '$lokasi_1' , ' ', ' ', ' ', ' ')";

    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

/* ========== VALIDASI UPLOAD GAMBAR ========== */
function upload_gambar()
{
    $namaFile = $_FILES['gambar']['name'];
    $ukuranFile = $_FILES['gambar']['size'];
    $error = $_FILES['gambar']['error'];
    $tmpName = $_FILES['gambar']['tmp_name'];

    // cek apakah tidak ada gambar yang diupload
    if ($error === 4) {
        echo "<script>
                alert('pilih gambar terlebih dahulu!');
            </script>";
        return false;
    }

    // cek apakah yang diupload adalah gambar
    $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
    $ekstensiGambar = explode('.', $namaFile);
    $ekstensiGambar = strtolower(end($ekstensiGambar));
    if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
        echo "<script>
                alert('File tidak sesuai format!');
            </script>";
        return false;
    }

    // cek jika ukuran gambar terlalu besar
    if ($ukuranFile > 3000000) {
        echo "<script>
                alert('Ukuran gambar terlalu besar!');
            </script>";
        return false;
    }

    // lolos pengecekan, gambar siap diupload
    // generate nama gambar baru
    $namaFileBaru = uniqid();
    $namaFileBaru .= '.';
    $namaFileBaru .= $ekstensiGambar;

    move_uploaded_file($tmpName, '../static/img/peserta/' . $namaFileBaru);

    return $namaFileBaru;
}

/* ========== EDIT DATA PESERTA ========== */
function edit_peserta($data)
{
    global $conn;
    // data diri peserta
    $id = $data["id"];
    $nik = htmlspecialchars($data["nik"]);
    $nama = htmlspecialchars($data["nama"]);
    $jenis_kelamin = htmlspecialchars($data["jenis_kelamin"]);
    $tanggal_lahir = htmlspecialchars($data["tanggal_lahir"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $gambar = htmlspecialchars($data["gambar"]);
    // detail pelaksanaan tes
    // $nomor_tes = htmlspecialchars($data["nomor_tes"]);
    $prodi = htmlspecialchars($data["prodi"]);
    $formasi = htmlspecialchars($data["formasi"]);
    $tahap_1 = htmlspecialchars($data["tahap_1"]);
    // $tahap_2 = htmlspecialchars($data["tahap_2"]);
    // $tahap_3 = htmlspecialchars($data["tahap_3"]);

    // upload gambar
    $gambar = upload_gambar();
    if (!$gambar) {
        return false;
    }

    // query insert data
    $query = "UPDATE peserta SET
                nik = '$nik',
                nama = '$nama',
                jenis_kelamin = '$jenis_kelamin',
                tanggal_lahir = '$tanggal_lahir',
                alamat = '$alamat',
                gambar = '$gambar',
                prodi = '$prodi',
                formasi = '$formasi',
                tahap_1 = '$tahap_1'
                WHERE id = '$id'";
    
    //mengeksekusi query
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

/* ========== EDIT DATA PENGAWAS ========== */
function edit_pengawas($data)
{
    global $conn;
    // data diri pengawas
    $id = $data["id"];
    $nama = htmlspecialchars($data["nama"]);
    $status = htmlspecialchars($data["status"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $nip = htmlspecialchars($data["nip"]);
    $password = htmlspecialchars($data["password"]);
    $gambar = htmlspecialchars($data["gambar"]);
    // detail pelaksanaan tes
    $tahap_1 = htmlspecialchars($data["tahap_1"]);
    $lokasi_1 = htmlspecialchars($data["lokasi_1"]);
    // $tahap_2 = htmlspecialchars($data["tahap_2"]);
    // $lokasi_2 = htmlspecialchars($data["lokasi_2"]);
    // $tahap_3 = htmlspecialchars($data["tahap_3"]);
    // $lokasi_3 = htmlspecialchars($data["lokasi_3"]);

    // upload gambar
    $gambar = upload_gambar();
    if (!$gambar) {
        return false;
    }

    // query insert data
    $query = "UPDATE pengawas SET
                nama = '$nama',
                status = '$status',
                alamat = '$alamat',
                nip = '$nip',
                password = '$password',
                gambar = '$gambar',
                tahap_1 = '$tahap_1',
                lokasi_1 = '$lokasi_1'
                WHERE id = '$id'";

    //mengeksekusi query
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

/* ========== HAPUS DATA PESERTA ========== */
function hapus_peserta($id)
{
    global $conn;
    mysqli_query($conn, "DELETE FROM peserta WHERE id = $id");
    return mysqli_affected_rows($conn);
}

/* ========== HAPUS DATA PENGAWAS ========== */
function hapus_pengawas($id)
{
    global $conn;
    mysqli_query($conn, "DELETE FROM pengawas WHERE id = $id");
    return mysqli_affected_rows($conn);
}

/* ========== CARI DATA PESERTA ========== */
function cari_peserta($keyword)
{
    $query = "SELECT * FROM peserta
                WHERE nama LIKE '%$keyword%' OR
                nik LIKE '%$keyword%' OR
                prodi LIKE '%$keyword%' OR
                formasi LIKE '%$keyword%'
                ";
    return query($query);
}

/* ========== CARI DATA PENGAWAS ========== */
function cari_pengawas($keyword)
{
    $query = "SELECT * FROM pengawas
                WHERE nama LIKE '%$keyword%' OR
                alamat LIKE '%$keyword%'
                ";
    return query($query);
}

?>
/* ========= AJAX CARI DATA ========= */
// mengambil elemen yang dibutuhkan
var keyword = document.getElementById('keyword');
var bottom = document.getElementById('bottom');
var content = document.getElementById('content');


// triger event ketika keyword di tulis
keyword.addEventListener('keyup', function () {
    // ajax
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            container.innerHTML = xhr.responseText;
        }
    }
    xhr.open('GET', '../ajax/pengawas.php?keyword=' + keyword.value, true);
    xhr.send();
}
);
<?php

require '../php/functions.php';

// menangkap output ajax untuk pencarian data
$keyword = $_GET["keyword"];
$query = "SELECT * FROM pengawas
            WHERE nama LIKE '%$keyword%' OR
            alamat LIKE '%$keyword%'
            ";

$pengawas = query($query);



?>

            <div class="content">
                <!-- box card untuk profil daftar pengawas -->
                <div class="box-container">
                    <?php foreach ($pengawas as $row) : ?>
                    <div class="box">
                        <img src="../static/img/pengawas/<?= $row['gambar']; ?>">
                        <div class="details">
                            <div class="status">
                                <h4><?= $row['nama']; ?></h4>
                                <p><?= $row['alamat']; ?></p>
                            </div>
                            <div class="action">
                                <button>
                                    <a href="edit-pengawas.php">
                                        <i class="fa-solid fa-edit"></i>
                                    </a>
                                </button>
                                <button>
                                    <a href="">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
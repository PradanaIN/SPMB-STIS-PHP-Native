<?php
// start session
session_start();
// cek session
if (!isset($_SESSION["login"]) && !isset($_SESSION["admin"])) {
    header("Location: ../login.php");
    exit;
}

require '../static/php/functions.php';

//mengambil id dari url
$id = $_GET["id"];

//mengecek data id berhasil dihapus atau tidak
if (hapus_pengawas($id) > 0) {
    echo "
        <script>
            alert('Data berhasil dihapus!');
            document.location.href = 'daftar-pengawas.php';
        </script>
    ";
} else {
    echo "
        <script>
            alert('Data gagal dihapus!');
            document.location.href = 'daftar-pengawas.php';
        </script>
    ";
}

?>
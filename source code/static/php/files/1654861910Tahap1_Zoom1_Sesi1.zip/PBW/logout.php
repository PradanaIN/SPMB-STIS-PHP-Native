<?php

session_start();
$_SESSION = [];
session_unset();
session_destroy();

// hapus cookie
setcookie('id', '', time() - 604800);
setcookie('pengawas', '', time() - 604800);
setcookie('admin', '', time() - 604800);

// kembalikan ke halaman login
header("Location: login.php");

?>
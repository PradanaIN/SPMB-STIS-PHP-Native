<?php
// start session
session_start();
// cek session
if (!isset($_SESSION["login"]) && !isset($_SESSION["admin"])) {
    header("Location: ../login.php");
    exit;
}

require '../static/php/functions.php';

//menegecek apakah tombol submit sudah dipencet belum
if (isset($_POST["submit"])) {

    //mengecek apakah data berhasil di tambahkan atau tidak
    if (tambah_peserta($_POST) > 0) {
        echo "
            <script>
                alert('Data berhasil ditambahkan!');
                document.location.href = 'daftar-peserta.php';
            </script>
        ";
    } else {
        echo "
            <script>
                alert('Data gagal ditambahkan!');
                document.location.href = 'daftar-peserta.php';
            </script>
        ";
    }
    
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../static/img/logo.png">
    <title>Laporan</title>
    <link rel="stylesheet" href="../static/css/laporan-try.css">
</head>
<body>
    <!-- Sidebar : navigasi halaman lainnya -->
    <div class="sidebar">
        <div class="logo-details">
            <img src="../static/img/logo.png">
            <div class="logo-name">
                SPMB
                <p>POLITEKNIK STATISTIKA STIS</p>
            </div>
            <i class="fa-solid fa-bars" id="btn"></i>
        </div>
        <ul class="nav-list">
            <li>
                <a href="dashboard.php">
                    <i class="fa-solid fa-house"></i>
                    <span class="links-name">Dashboard</span>
                </a>
                <span class="tooltip">Dashboard</span>
            </li>
            <li>
                <a href="daftar-pengawas.php">
                    <i class="fa-solid fa-user-tie"></i>
                    <span class="links-name">Pengawas</span>
                </a>
                <span class="tooltip">Pengawas</span>
            </li>
            <li>
                <a href="daftar-peserta.php">
                    <i class="fa-solid fa-user"></i>
                    <span class="links-name">Peserta</span>
                </a>
                <span class="tooltip">Peserta</span>
            </li>
            <li>
                <a href="pesan.php">
                    <i class="fa-solid fa-envelope"></i>
                    <span class="links-name">Pesan</span>
                </a>
                <span class="tooltip">Pesan</span>
            </li>
            <li>
                <a href="jadwal.php">
                    <i class="fa-solid fa-calendar-alt"></i>
                    <span class="links-name">Jadwal</span>
                </a>
                <span class="tooltip">Jadwal</span>
            </li>
            <li>
                <a href="laporan.php">
                    <i class="fa-solid fa-file-alt"></i>
                    <span class="links-name">Laporan</span>
                </a>
                <span class="tooltip">Laporan</span>
            </li>
            <li class="profile">
                <div class="profile-details">
                    <!-- <img src="profile.jpg" alt="profileImg"> -->
                    <div class="name_status">
                        <div class="name">Novanni Indi Pradana</div>
                        <div class="status">Admin</div>
                    </div>
                </div>
                <a href="../logout.php" id="logout">
                    <i class="fa-solid fa-sign-out-alt" id="logout"></i>
                    <span class="tooltip">Log Out</span>
                </a>
            </li>
        </ul>
    </div>
    <!-- Section : konten yang ditampilkan -->
    <section>
        <div class="container">
            <!-- Header : judul halaman dan akun aktif pengguna -->
            <div class="header">
                <h3>Laporan</h3>
                <div class="user-profile">
                    <div class="status">
                        <h4>Nama</h4>
                        <p>Admin</p>
                    </div>
                    <div class="photo">
                        <img src="https://www.pngitem.com/pimgs/m/146-1468479_my-profile-icon-blank-profile-picture-circle-hd.png" width="50">
                    </div>
                </div>
            </div>
            <div class="content">
                <form method="post" enctype="multipart/form-data">
                    <div class="form first">
                        <div class="details personal">
                            <span class="title">Data Pelaksanaan Tes</span>
        
                            <div class="fields">

                                <div class="input-field">
                                    <label>Nama Pengawas</label>
                                    <input type="text" id="nama" name="nama" placeholder="Masukkan nama lengkap" required>
                                </div>

                                <div class="input-field">
                                    <label>Nomor Induk Pegawai</label>
                                    <input type="text" id="nip" name="nip"  placeholder="masukkan NIP" required>
                                </div>

                                <div class="input-field">
                                    <label>Tanggal Tes</label>
                                    <input type="date" name="tanggal_tes" id="tanggal_tes" required>
                                </div>
        
                                <div class="input-field">
                                    <label>Lokasi Tes</label>
                                    <select id="lokasi" name="lokasi" required>
                                        <option value="" disabled selected>Pilih Lokasi Tes</option>
                                        <option value="Zoom 001">Zoom 001</option>
                                        <option value="Zoom 002">Zoom 002</option>
                                        <option value="Zoom 003">Zoom 003</option>
                                    </select>
                                </div>

                                <div class="input-field">
                                    <label>Sesi Tes</label>
                                    <select id="sesi" name="sesi" required>
                                        <option value="" disabled selected>Pilih Sesi Tes</option>
                                        <option value="Sesi 1">Sesi 1</option>
                                        <option value="Sesi 2">Sesi 2</option>
                                        <option value="Sesi 3">Sesi 3</option>
                                    </select>
                                </div>

                                <div class="input-field">
                                    <label>Jumlah Peserta</label>
                                    <input type="text" name="jumlah_peserta" id="jumlah_peserta" required>

                            </div>
                        </div>
        
                        <div class="details ID">
                            <span class="title">File Laporan Tes</span>
        
                            <div class="fields">
                                
                                <div class="wrapper">
                                    <form action="#">
                                        <input class="file-input" type="file" name="file" hidden>
                                        <i class="fas fa-cloud-upload-alt"></i>
                                        <p>Pilih Berkas Upload</p>
                                    </form>
                                    <div class="progress-area" id="section"></div>
                                    <div class="uploaded-area" id="section"></div>
                                </div>

                            </div>

                            <div class="buttons">

                                <input type="reset" class="reset" id="button" name="reset" value="Batal"></input>

                                <input type="submit" class="submit" id="button" name="submit" value="Upload"></input>

                            </div>
                        </div> 
                    </div>
                </form>
            </div>
        </div>
    </section>

    <!-- JavaScript -->
    <script src="../static/js/unggah-laporan.js"></script>
    <script src="https://kit.fontawesome.com/6265d9d0e3.js" crossorigin="anonymous"></script>
</body>
</html>

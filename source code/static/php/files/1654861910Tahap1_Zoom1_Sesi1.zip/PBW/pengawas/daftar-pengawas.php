<?php
// start session
session_start();
// cek session
if (!isset($_SESSION["login"]) && !isset($_SESSION["pengawas"]) && isset($_SESSION["admin"])) {
    header("Location: ../login.php");
    exit;
}

// import function
require '../static/php/functions.php';

// memanggil query yang dibutuhkan
$pengawas = query("SELECT * FROM pengawas");

// ketika tombol cari ditekan, maka database baru akan menimpa databse di atas
if (isset($_POST["keyword"])) {
    $pengawas = cari_pengawas($_POST["keyword"]);
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../static/img/logo.png">
    <title>Daftar Pengawas</title>
    <link rel="stylesheet" href="../static/css/daftar-pengawas.css">
</head>
<body>
    <!-- Sidebar : navigasi halaman lainnya -->
    <div class="sidebar">
        <div class="logo-details">
            <img src="../static/img/logo.png">
            <div class="logo-name">
                SPMB
                <p>POLITEKNIK STATISTIKA STIS</p>
            </div>
            <i class="fa-solid fa-bars" id="btn"></i>
        </div>
        <ul class="nav-list">
            <li>
                <a href="dashboard.php">
                    <i class="fa-solid fa-house"></i>
                    <span class="links-name">Dashboard</span>
                </a>
                <span class="tooltip">Dashboard</span>
            </li>
            <li>
                <a href="daftar-pengawas.php">
                    <i class="fa-solid fa-user-tie"></i>
                    <span class="links-name">Pengawas</span>
                </a>
                <span class="tooltip">Pengawas</span>
            </li>
            <li>
                <a href="daftar-peserta.php">
                    <i class="fa-solid fa-user"></i>
                    <span class="links-name">Peserta</span>
                </a>
                <span class="tooltip">Peserta</span>
            </li>
            <li>
                <a href="pesan.php">
                    <i class="fa-solid fa-envelope"></i>
                    <span class="links-name">Pesan</span>
                </a>
                <span class="tooltip">Pesan</span>
            </li>
            <li>
                <a href="jadwal.php">
                    <i class="fa-solid fa-calendar-alt"></i>
                    <span class="links-name">Jadwal</span>
                </a>
                <span class="tooltip">Jadwal</span>
            </li>
            <li>
                <a href="laporan.php">
                    <i class="fa-solid fa-file-alt"></i>
                    <span class="links-name">Laporan</span>
                </a>
                <span class="tooltip">Laporan</span>
            </li>
            <li class="profile">
                <div class="profile-details">
                    <!-- <img src="profile.jpg" alt="profileImg"> -->
                    <div class="name_status">
                        <div class="name">Novanni Indi Pradana</div>
                        <div class="status">Admin</div>
                    </div>
                </div>
                <a href="../logout.php" id="logout">
                    <i class="fa-solid fa-sign-out-alt" id="logout"></i>
                    <span class="tooltip">Log Out</span>
                </a>
            </li>
        </ul>
    </div>
    <!-- Section : konten yang ditampilkan -->
    <section>
        <div class="container">
            <!-- Header : judul halaman dan akun aktif pengguna -->
            <div class="header">
                <div class="top">
                    <h3>Daftar Pengawas</h3>
                    <div class="user-profile">
                        <div class="status">
                            <h4>Nama</h4>
                            <p>Admin</p>
                        </div>
                        <div class="photo">
                            <img src="https://www.pngitem.com/pimgs/m/146-1468479_my-profile-icon-blank-profile-picture-circle-hd.png" width="50">
                        </div>
                    </div>
                </div>
                <div class="bottom">
                    <form class="search" method="post">
                        <!-- icon search -->
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input type="search" placeholder="Cari" name="keyword" autocomplete="off" id="keyword">
                    </form>
                    <!-- <div class="add">
                        <a href="tambah-pengawas.php">
                            <i class="fa-solid fa-plus"></i>
                            <p>Pengawas Baru</p>
                        </a>
                    </div> -->
                </div>
            </div>
            <!-- Content : tabel daftar pengawas spmb -->
            <div class="content">
                <!-- box card untuk profil daftar pengawas -->
                <div class="box-container">
                    <?php foreach ($pengawas as $row) : ?>
                    <div class="box">
                        <img src="../static/img/pengawas/<?= $row['gambar']; ?>">
                        <div class="details">
                            <div class="status">
                                <h4><?= $row['nama']; ?></h4>
                                <p><?= $row['alamat']; ?></p>
                            </div>
                            <!-- <div class="action">
                                <button>
                                    <a href="edit-pengawas.php?id=<?= $row["id"]; ?>">
                                        <i class="fa-solid fa-edit"></i>
                                    </a>
                                </button>
                                <button>
                                    <a href="hapus-pengawas.php?id=<?= $row["id"]; ?>" onclick="return confirm('Hapus data terpilih?')">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </button>
                            </div> -->
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- JavaScript -->
    <script src="../static/js/script.js"></script>
    <script src="../static/js/pengawas.js"></script>
    <script src="https://kit.fontawesome.com/6265d9d0e3.js" crossorigin="anonymous"></script>
</body>
</html>
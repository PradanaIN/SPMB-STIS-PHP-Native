package com.example.demo.services;

import com.example.demo.models.Student;
import com.example.demo.models.StudentRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author nanoy
 * Business/Logic Layer
 */
@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepo; 
    
    public List<Student> listAll() {
        return (List<Student>) studentRepo.findAll();
    }
    
    public void save(Student student) {
        studentRepo.save(student);
    }
    
    public Student get(Long id) {
        return studentRepo.findById(id).get();
    }
    
    public void delete(Long id) {
        studentRepo.deleteById(id);
    }
    
}

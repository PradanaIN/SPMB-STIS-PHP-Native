package com.example.demo.models;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author nanoy
 */

@Entity
@Table(name = "student")
public class Student implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public void setId(Long id) {
        this.id = id;
    }
    
    private String nama;
    private int umur;
    private String jk;

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public void setJk(String jk) {
        this.jk = jk;
    }

    public Long getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public int getUmur() {
        return umur;
    }

    public String getJk() {
        return jk;
    }
    
    public Student() {
        //syarat beans
    }
    
    protected Student(String nama, int umur, String jk) {
        this.nama = nama;
        this.umur = umur;
        this.jk = jk;
    }
    
    @Override
    public String toString() {
        return id+ "-" + nama + "-" + umur + "-" + jk; 
    }
}

package com.example.demo.models;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

/**
 * @author nanoy
 * 
 *  extends the CrudRepository interface which defines standard CRUD operations. 
 *  In the generic parameters, we specify the domain type to work with is Student
 *  and the type of domain's ID (Student) is Long.
 */
@Component
public interface StudentRepository extends CrudRepository<Student, Long>{
    /* This method signature follows convention for a finder method findByXXX()
       where XXX is the property name in the model class */
    public List<Student> findByNama(String nama);
    
    //@Query("SELECT e FROM student WHERE e.umur >= :umur")
    //public List<Student> listStudentWithUmurOver (@Param("umur") int umur );
}

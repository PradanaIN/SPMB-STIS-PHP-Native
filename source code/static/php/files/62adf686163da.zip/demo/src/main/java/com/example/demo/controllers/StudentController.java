package com.example.demo.controllers;

import com.example.demo.models.Student;
import com.example.demo.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author nanoy
 */
@Controller
public class StudentController {
    @Autowired
    StudentService studentService; 
    
    @RequestMapping("/student")
    public String viewStudent (Model model){
        model.addAttribute("listStudent",studentService.listAll());
        return "student_list";
    }    
    
    @RequestMapping("/")
    public String index () {
        return "index";
    }
    
    @RequestMapping("/student/create")
    public String createStudent(Model model) {
        Student student = new Student();
        model.addAttribute("student",student);
        return "student_create";
    }
    
    @RequestMapping(value = "/student/save", method = RequestMethod.POST)
    public String saveStudent(@ModelAttribute("student") Student student) {        
        studentService.save(student);
        return "redirect:/student";
    }
    
    @RequestMapping("/student/edit/{id}")
    public ModelAndView showEditStudentPage(@PathVariable(name = "id") int id) {
        ModelAndView mav = new ModelAndView("student_edit");
        Student student = studentService.get((long)id);
        mav.addObject("student", student);

        return mav;
    }
    
    @RequestMapping("/student/delete/{id}")
    public String deleteStudent(@PathVariable(name = "id") int id) {
        studentService.delete((long)id);
        return "redirect:/student";       
    }
}
